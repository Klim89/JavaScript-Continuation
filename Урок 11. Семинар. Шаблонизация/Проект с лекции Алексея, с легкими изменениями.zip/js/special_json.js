const data = `
{
    "sammy": {
        "username":"SammyShark",
        "location": "Indian Ocean",
        "online": true,
        "followers": 987
    },
    "jesse": {
        "username":"JesseOctopus",
        "location": "Pasific Ocean",
        "online": false,
        "followers": 432
    }
}
`;
