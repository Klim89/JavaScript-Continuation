const productsData = [
  {
    src: "img.png",
    alt: "img obj data",
    name: "Название из project data",
    link: "product.html",
    des: "Описание товара",
    price: 500,
    currency: "$",
  },
  {
    src: "img2.png",
    alt: "img2 obj data",
    name: "Название2 из project data",
    link: "product2.html",
    des: "Описание2 товара",
    price: 510,
    currency: "€",
  },
  {
    src: "img3.png",
    alt: "img3 obj data",
    name: "Название3 из project data",
    link: "product3.html",
    des: "Описание3 товара",
    price: 610,
    currency: "₽",
  },
];

productsData.forEach((productData) => {
  const productBox = document.querySelector(".product-box");
  const productEl = document.createElement("div");
  productEl.classList.add("product");

  const productImg = document.createElement("img");

  productImg.classList.add("product__img");
  productImg.setAttribute("alt", productData.alt);
  productImg.src = productData.src;

  const productContent = document.createElement("div");
  productContent.classList.add("product__content");

  const productLink = document.createElement("a");
  productLink.href = productData.link;
  productLink.textContent = productData.name;

  const productText = document.createElement("h2");
  productText.classList.add("product__text");
  productText.textContent = productData.des;

  const productPrice = document.createElement("p");
  productPrice.classList.add("product__price");
  productPrice.textContent = productData.price;

  const productCurrency = document.createElement("p");
  productCurrency.classList.add("product__currency");
  productCurrency.textContent = productData.currency;

  productContent.appendChild(productLink);
  productContent.appendChild(productText);
  productContent.appendChild(productPrice);
  productContent.appendChild(productCurrency);

  productEl.appendChild(productImg);
  productEl.appendChild(productContent);

  productBox.appendChild(productEl);
});
