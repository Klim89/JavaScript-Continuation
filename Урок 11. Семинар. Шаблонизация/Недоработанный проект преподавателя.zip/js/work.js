const dataProducts = `[
  {
    "name": "MANGO  PEOPLE  T-SHIRT",
    "price": "300",
    "color": "red",
    "size": "XL",
    "quantity": 2,
    "image":"",
  },
  {
    "name": "ELLERY X M'O CAPSULE",
    "price": "52",
    "color": "black",
    "size": "XL",
    "quantity": 1,
    "image":"",
  },
]`;
